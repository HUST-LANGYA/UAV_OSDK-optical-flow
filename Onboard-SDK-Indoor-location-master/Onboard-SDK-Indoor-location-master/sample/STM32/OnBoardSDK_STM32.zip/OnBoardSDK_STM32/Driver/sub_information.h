#ifndef __SUB_INFORMATION_H
#define __SUB_INFORMATION_H
#include "dji_vehicle.hpp"
#include "global_variable.h"

extern void Sub_50HZ_Information_Task();
extern void Sub_1000HZ_Information_Task();


#endif
