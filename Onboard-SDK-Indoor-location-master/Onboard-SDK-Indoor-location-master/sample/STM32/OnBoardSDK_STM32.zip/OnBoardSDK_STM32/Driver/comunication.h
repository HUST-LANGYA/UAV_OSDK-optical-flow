#ifndef __COMUNICATION_H
#define __COMUNICATION_H
#include "dji_vehicle.hpp"

extern void UsartConfig();



#endif