#ifndef __TIME_H
#define __TIME_H

extern void Timer_Condfig();
extern void SystickConfig();

#endif
